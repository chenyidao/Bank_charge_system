﻿--银行表
CREATE TABLE "Bank" (
"bank_code" VARCHAR2(255 BYTE) NOT NULL,
"bank_name" VARCHAR2(255 BYTE) NOT NULL,
CONSTRAINT "SYS_C0011167" PRIMARY KEY ("bank_code") 
)
TABLESPACE USERS
LOGGING
NOCOMPRESS 
NOCACHE
NOPARALLEL ;
ALTER TABLE "Bank" ADD CONSTRAINT "SYS_C0011141" CHECK ("bank_code" IS NOT NULL) ENABLE;
ALTER TABLE "Bank" ADD CONSTRAINT "SYS_C0011242" CHECK ("bank_name" IS NOT NULL) ENABLE;
COMMENT ON COLUMN "Bank"."bank_code" IS '银行编码';
COMMENT ON COLUMN "Bank"."bank_name" IS '银行名字';

--银行业务流水表
CREATE TABLE "Bank_Business_System" (
"bank_flow_num" NUMBER(10,0) NOT NULL,
"bank_code" VARCHAR2(255 BYTE) NOT NULL,
"user_id" NUMBER(10,0) NOT NULL,
"user_name" VARCHAR2(255 BYTE) NOT NULL,
"transaction_time" DATE NULL,
"transaction_money" NUMBER(10,2) NOT NULL,
"transaction_type" VARCHAR2(255 BYTE) NULL,
CONSTRAINT "SYS_C0011233" PRIMARY KEY ("bank_flow_num") 
)
TABLESPACE USERS
LOGGING
NOCOMPRESS 
NOCACHE
NOPARALLEL ;
ALTER TABLE "Bank_Business_System" ADD CONSTRAINT "SYS_C0011228" CHECK ("bank_flow_num" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Business_System" ADD CONSTRAINT "SYS_C0011229" CHECK ("bank_code" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Business_System" ADD CONSTRAINT "SYS_C0011230" CHECK ("user_id" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Business_System" ADD CONSTRAINT "SYS_C0011231" CHECK ("user_name" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Business_System" ADD CONSTRAINT "SYS_C0011232" CHECK ("transaction_money" IS NOT NULL) ENABLE;
COMMENT ON COLUMN "Bank_Business_System"."bank_flow_num" IS '银行交易流水号';
COMMENT ON COLUMN "Bank_Business_System"."bank_code" IS '银行编码';
COMMENT ON COLUMN "Bank_Business_System"."user_id" IS '用户id';
COMMENT ON COLUMN "Bank_Business_System"."user_name" IS '用户名';
COMMENT ON COLUMN "Bank_Business_System"."transaction_time" IS '交易时间';
COMMENT ON COLUMN "Bank_Business_System"."transaction_money" IS '交易金额';
COMMENT ON COLUMN "Bank_Business_System"."transaction_type" IS '交易类型';

--对账明细表
CREATE TABLE "Bank_Check_detail" (
"bce_flow_num" NUMBER(10,0) NOT NULL,
"check_time" DATE NOT NULL,
"bank_code" VARCHAR2(255 BYTE) NOT NULL,
"bank_flow_num" NUMBER(10,0) NOT NULL,
"user_id" NUMBER(10,0) NOT NULL,
"bank_money" NUMBER(10,2) NOT NULL,
"our_money" NUMBER(10,2) NOT NULL,
"exception_type" VARCHAR2(255 BYTE) NULL,
CONSTRAINT "SYS_C0011261" PRIMARY KEY ("bce_flow_num") 
)
TABLESPACE USERS
LOGGING
NOCOMPRESS 
NOCACHE
NOPARALLEL ;
ALTER TABLE "Bank_Check_detail" ADD CONSTRAINT "SYS_C0011170" CHECK ("check_time" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Check_detail" ADD CONSTRAINT "SYS_C0011255" CHECK ("bank_flow_num" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Check_detail" ADD CONSTRAINT "SYS_C0011256" CHECK ("user_id" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Check_detail" ADD CONSTRAINT "SYS_C0011257" CHECK ("bce_flow_num" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Check_detail" ADD CONSTRAINT "SYS_C0011258" CHECK ("bank_code" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Check_detail" ADD CONSTRAINT "SYS_C0011259" CHECK ("bank_money" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Check_detail" ADD CONSTRAINT "SYS_C0011260" CHECK ("our_money" IS NOT NULL) ENABLE;
COMMENT ON COLUMN "Bank_Check_detail"."bce_flow_num" IS '对账流水号';
COMMENT ON COLUMN "Bank_Check_detail"."check_time" IS '对账时间';
COMMENT ON COLUMN "Bank_Check_detail"."bank_code" IS '银行编码';
COMMENT ON COLUMN "Bank_Check_detail"."bank_flow_num" IS '银行流水号';
COMMENT ON COLUMN "Bank_Check_detail"."user_id" IS '客户id';
COMMENT ON COLUMN "Bank_Check_detail"."bank_money" IS '银行金额';
COMMENT ON COLUMN "Bank_Check_detail"."our_money" IS '企业方金额';
COMMENT ON COLUMN "Bank_Check_detail"."exception_type" IS '异常类型及说明';

--对总账表
CREATE TABLE "Bank_Check_Total" (
"bct_flow_num" NUMBER(10,0) NOT NULL,
"check_date" DATE NOT NULL,
"bank_code" VARCHAR2(255 BYTE) NOT NULL,
"bank_total_count" NUMBER(10,0) NOT NULL,
"bank_total_money" NUMBER(10,2) NOT NULL,
"our_total_count" NUMBER(10,0) NOT NULL,
"our_total_money" NUMBER(10,2) NOT NULL,
"is_success" VARCHAR2(255 BYTE) NOT NULL,
CONSTRAINT "SYS_C0011251" PRIMARY KEY ("bct_flow_num") 
)
TABLESPACE USERS
LOGGING
NOCOMPRESS 
NOCACHE
NOPARALLEL ;
ALTER TABLE "Bank_Check_Total" ADD CONSTRAINT "SYS_C0011243" CHECK ("bct_flow_num" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Check_Total" ADD CONSTRAINT "SYS_C0011244" CHECK ("check_date" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Check_Total" ADD CONSTRAINT "SYS_C0011245" CHECK ("bank_code" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Check_Total" ADD CONSTRAINT "SYS_C0011246" CHECK ("bank_total_count" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Check_Total" ADD CONSTRAINT "SYS_C0011247" CHECK ("bank_total_money" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Check_Total" ADD CONSTRAINT "SYS_C0011248" CHECK ("our_total_count" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Check_Total" ADD CONSTRAINT "SYS_C0011249" CHECK ("our_total_money" IS NOT NULL) ENABLE;
ALTER TABLE "Bank_Check_Total" ADD CONSTRAINT "SYS_C0011250" CHECK ("is_success" IS NOT NULL) ENABLE;
COMMENT ON COLUMN "Bank_Check_Total"."bct_flow_num" IS '对账流水号';
COMMENT ON COLUMN "Bank_Check_Total"."check_date" IS '对账日期';
COMMENT ON COLUMN "Bank_Check_Total"."bank_code" IS '银行编码';
COMMENT ON COLUMN "Bank_Check_Total"."bank_total_count" IS '银行总笔数';
COMMENT ON COLUMN "Bank_Check_Total"."bank_total_money" IS '银行总金额';
COMMENT ON COLUMN "Bank_Check_Total"."our_total_count" IS '企业方总笔数';
COMMENT ON COLUMN "Bank_Check_Total"."our_total_money" IS '企业方总金额';
COMMENT ON COLUMN "Bank_Check_Total"."is_success" IS '对账是否成功(00：成功，01：失败)';

--基本码表
CREATE TABLE "Code_Table" (
"c_key" VARCHAR2(255 BYTE) NOT NULL,
"c_value" VARCHAR2(255 BYTE) NOT NULL,
CONSTRAINT "SYS_C0011282" PRIMARY KEY ("c_key") 
)
TABLESPACE USERS
LOGGING
NOCOMPRESS 
NOCACHE
NOPARALLEL ;
ALTER TABLE "Code_Table" ADD CONSTRAINT "SYS_C0011280" CHECK ("c_key" IS NOT NULL) ENABLE;
ALTER TABLE "Code_Table" ADD CONSTRAINT "SYS_C0011281" CHECK ("c_value" IS NOT NULL) ENABLE;

--设备表
CREATE TABLE "Device" (
"device_id" NUMBER(10,0) NOT NULL,
"user_id" NUMBER(10,0) NULL,
"owned_balance" NUMBER(10,2) NULL,
"type" VARCHAR2(255 BYTE) NOT NULL,
CONSTRAINT "SYS_C0011077" PRIMARY KEY ("device_id") 
)
TABLESPACE USERS
LOGGING
NOCOMPRESS 
NOCACHE
NOPARALLEL ;
ALTER TABLE "Device" ADD CONSTRAINT "SYS_C0011136" CHECK ("type" IS NOT NULL) ENABLE;
COMMENT ON COLUMN "Device"."device_id" IS '设备ID';
COMMENT ON COLUMN "Device"."user_id" IS '用户id';
COMMENT ON COLUMN "Device"."owned_balance" IS '欠费余额';
COMMENT ON COLUMN "Device"."type" IS '设备类型';

--应缴费表
CREATE TABLE "List_Of_Fees" (
"eb_id" NUMBER(10,0) NOT NULL,
"user_id" NUMBER(10,0) NOT NULL,
"device_id" NUMBER(10,0) NOT NULL,
"mt_date" DATE NOT NULL,
"begin_num" NUMBER(10,0) NOT NULL,
"end_num" NUMBER(10,0) NOT NULL,
"basic_fee" NUMBER(10,2) NULL,
"add1_fee" NUMBER(10,2) NOT NULL,
"add2_fee" NUMBER(10,2) NOT NULL,
"should_pay" NUMBER(10,2) NOT NULL,
"actual_pay" NUMBER(10,2) NULL,
"penalty" NUMBER(10,2) NULL,
"should_date" DATE NULL,
"actual_date" DATE NULL,
"pay_state" VARCHAR2(255 BYTE) NULL,
"device_type" VARCHAR2(255 BYTE) NULL,
CONSTRAINT "SYS_C0011227" PRIMARY KEY ("eb_id") 
)
TABLESPACE USERS
LOGGING
NOCOMPRESS 
NOCACHE
NOPARALLEL ;
ALTER TABLE "List_Of_Fees" ADD CONSTRAINT "SYS_C0011223" CHECK ("eb_id" IS NOT NULL) ENABLE;
ALTER TABLE "List_Of_Fees" ADD CONSTRAINT "SYS_C0011224" CHECK ("user_id" IS NOT NULL) ENABLE;
ALTER TABLE "List_Of_Fees" ADD CONSTRAINT "SYS_C0011225" CHECK ("device_id" IS NOT NULL) ENABLE;
ALTER TABLE "List_Of_Fees" ADD CONSTRAINT "SYS_C0011226" CHECK ("mt_date" IS NOT NULL) ENABLE;
ALTER TABLE "List_Of_Fees" ADD CONSTRAINT "SYS_C0011343" CHECK ("begin_num" IS NOT NULL) ENABLE;
ALTER TABLE "List_Of_Fees" ADD CONSTRAINT "SYS_C0011344" CHECK ("end_num" IS NOT NULL) ENABLE;
ALTER TABLE "List_Of_Fees" ADD CONSTRAINT "SYS_C0011346" CHECK ("add1_fee" IS NOT NULL) ENABLE;
ALTER TABLE "List_Of_Fees" ADD CONSTRAINT "SYS_C0011347" CHECK ("add2_fee" IS NOT NULL) ENABLE;
ALTER TABLE "List_Of_Fees" ADD CONSTRAINT "SYS_C0011348" CHECK ("should_pay" IS NOT NULL) ENABLE;
COMMENT ON COLUMN "List_Of_Fees"."eb_id" IS '电费清单编号';
COMMENT ON COLUMN "List_Of_Fees"."user_id" IS '用户id';
COMMENT ON COLUMN "List_Of_Fees"."device_id" IS '设备id';
COMMENT ON COLUMN "List_Of_Fees"."mt_date" IS '抄表日期';
COMMENT ON COLUMN "List_Of_Fees"."begin_num" IS '起始读数';
COMMENT ON COLUMN "List_Of_Fees"."end_num" IS '最终读数';
COMMENT ON COLUMN "List_Of_Fees"."basic_fee" IS '基本费用';
COMMENT ON COLUMN "List_Of_Fees"."add1_fee" IS '附加费用1';
COMMENT ON COLUMN "List_Of_Fees"."add2_fee" IS '附加费用2';
COMMENT ON COLUMN "List_Of_Fees"."should_pay" IS '应缴费用';
COMMENT ON COLUMN "List_Of_Fees"."actual_pay" IS '实缴费用';
COMMENT ON COLUMN "List_Of_Fees"."penalty" IS '违约金';
COMMENT ON COLUMN "List_Of_Fees"."should_date" IS '应缴日期';
COMMENT ON COLUMN "List_Of_Fees"."actual_date" IS '实缴日期';
COMMENT ON COLUMN "List_Of_Fees"."pay_state" IS '缴费状态(0:未缴 1:已缴 )';
COMMENT ON COLUMN "List_Of_Fees"."device_type" IS '设备类型';

--抄表记录表
CREATE TABLE "Meter_Recording" (
"mr_id" NUMBER(10,0) NOT NULL,
"current_meters" NUMBER(10,0) NULL,
"user_id" NUMBER(10,0) NULL,
"device_id" NUMBER NULL,
"mt_date" DATE NULL,
"staff_id" NUMBER NULL,
CONSTRAINT "SYS_C0011207" PRIMARY KEY ("mr_id") 
)
TABLESPACE USERS
LOGGING
NOCOMPRESS 
NOCACHE
NOPARALLEL ;
COMMENT ON COLUMN "Meter_Recording"."mr_id" IS '抄表编号';
COMMENT ON COLUMN "Meter_Recording"."current_meters" IS '当前电表数';
COMMENT ON COLUMN "Meter_Recording"."user_id" IS '用户id';
COMMENT ON COLUMN "Meter_Recording"."device_id" IS '设备id';
COMMENT ON COLUMN "Meter_Recording"."mt_date" IS '抄表日期';
COMMENT ON COLUMN "Meter_Recording"."staff_id" IS '抄表人id';

--抄表员表
CREATE TABLE "Meter_Staff" (
"staff_id" NUMBER(10,0) NOT NULL,
"staff_name" VARCHAR2(255 BYTE) NOT NULL,
"staff_telephone" VARCHAR2(255 BYTE) NOT NULL,
CONSTRAINT "SYS_C0011180" PRIMARY KEY ("staff_id") 
)
TABLESPACE USERS
LOGGING
NOCOMPRESS 
NOCACHE
NOPARALLEL ;
ALTER TABLE "Meter_Staff" ADD CONSTRAINT "SYS_C0011178" CHECK ("staff_name" IS NOT NULL) ENABLE;
ALTER TABLE "Meter_Staff" ADD CONSTRAINT "SYS_C0011179" CHECK ("staff_telephone" IS NOT NULL) ENABLE;
COMMENT ON COLUMN "Meter_Staff"."staff_id" IS '抄表员工id';
COMMENT ON COLUMN "Meter_Staff"."staff_name" IS '抄表员工姓名';
COMMENT ON COLUMN "Meter_Staff"."staff_telephone" IS '抄表员工电话';

--用户支付记录表
CREATE TABLE "Payment_record" (
"pay_id" NUMBER(10,0) NOT NULL,
"user_id" NUMBER(10,0) NOT NULL,
"pay_time" DATE NOT NULL,
"pay_amount" NUMBER(10,2) NOT NULL,
"pay_type" VARCHAR2(255 BYTE) NOT NULL,
"bank_code" VARCHAR2(255 BYTE) NOT NULL,
"bank_flow_num" NUMBER(10,0) NOT NULL,
CONSTRAINT "SYS_C0011241" PRIMARY KEY ("pay_id") 
)
TABLESPACE USERS
LOGGING
NOCOMPRESS 
NOCACHE
NOPARALLEL ;
ALTER TABLE "Payment_record" ADD CONSTRAINT "SYS_C0011234" CHECK ("pay_id" IS NOT NULL) ENABLE;
ALTER TABLE "Payment_record" ADD CONSTRAINT "SYS_C0011235" CHECK ("user_id" IS NOT NULL) ENABLE;
ALTER TABLE "Payment_record" ADD CONSTRAINT "SYS_C0011236" CHECK ("pay_time" IS NOT NULL) ENABLE;
ALTER TABLE "Payment_record" ADD CONSTRAINT "SYS_C0011237" CHECK ("pay_amount" IS NOT NULL) ENABLE;
ALTER TABLE "Payment_record" ADD CONSTRAINT "SYS_C0011238" CHECK ("pay_type" IS NOT NULL) ENABLE;
ALTER TABLE "Payment_record" ADD CONSTRAINT "SYS_C0011239" CHECK ("bank_code" IS NOT NULL) ENABLE;
ALTER TABLE "Payment_record" ADD CONSTRAINT "SYS_C0011240" CHECK ("bank_flow_num" IS NOT NULL) ENABLE;
COMMENT ON COLUMN "Payment_record"."pay_id" IS '缴费编号';
COMMENT ON COLUMN "Payment_record"."user_id" IS '用户id';
COMMENT ON COLUMN "Payment_record"."pay_time" IS '缴费时间';
COMMENT ON COLUMN "Payment_record"."pay_amount" IS '缴费金额';
COMMENT ON COLUMN "Payment_record"."pay_type" IS '缴费类型(01=缴费，02=冲正)';
COMMENT ON COLUMN "Payment_record"."bank_code" IS '银行编码';
COMMENT ON COLUMN "Payment_record"."bank_flow_num" IS '银行流水号';

--客户表
CREATE TABLE "User" (
"user_id" NUMBER(10,0) NOT NULL,
"user_name" VARCHAR2(255 BYTE) NOT NULL,
"telephone" VARCHAR2(255 BYTE) NOT NULL,
"address" VARCHAR2(255 BYTE) NULL,
"balance" NUMBER(10,2) NOT NULL,
CONSTRAINT "SYS_C0011211" PRIMARY KEY ("user_id") 
)
TABLESPACE USERS
LOGGING
NOCOMPRESS 
NOCACHE
NOPARALLEL ;
ALTER TABLE "User" ADD CONSTRAINT "SYS_C0011210" CHECK ("user_id" IS NOT NULL) ENABLE;
ALTER TABLE "User" ADD CONSTRAINT "SYS_C0011212" CHECK ("user_name" IS NOT NULL) ENABLE;
ALTER TABLE "User" ADD CONSTRAINT "SYS_C0011213" CHECK ("telephone" IS NOT NULL) ENABLE;
ALTER TABLE "User" ADD CONSTRAINT "SYS_C0011214" CHECK ("balance" IS NOT NULL) ENABLE;
COMMENT ON COLUMN "User"."user_id" IS '用户id';
COMMENT ON COLUMN "User"."user_name" IS '用户姓名';
COMMENT ON COLUMN "User"."telephone" IS '用户电话';
COMMENT ON COLUMN "User"."address" IS '用户地址';
COMMENT ON COLUMN "User"."balance" IS '账户余额';


ALTER TABLE "Bank_Business_System" ADD CONSTRAINT "user_bank" FOREIGN KEY ("user_id") REFERENCES "User" ("user_id") ON DELETE SET NULL;
ALTER TABLE "Bank_Check_detail" ADD CONSTRAINT "check_detail" FOREIGN KEY ("bank_flow_num") REFERENCES "Bank_Business_System" ("bank_flow_num") ON DELETE SET NULL;
ALTER TABLE "Bank_Check_detail" ADD CONSTRAINT "check_detail1" FOREIGN KEY ("bank_code") REFERENCES "Bank" ("bank_code") ON DELETE SET NULL;
ALTER TABLE "Bank_Check_Total" ADD CONSTRAINT "check_total" FOREIGN KEY ("bank_code") REFERENCES "Bank" ("bank_code") ON DELETE SET NULL;
ALTER TABLE "List_Of_Fees" ADD CONSTRAINT "device_l" FOREIGN KEY ("device_id") REFERENCES "Device" ("device_id") ON DELETE SET NULL;
ALTER TABLE "List_Of_Fees" ADD CONSTRAINT "user_l" FOREIGN KEY ("user_id") REFERENCES "User" ("user_id") ON DELETE SET NULL;
ALTER TABLE "Meter_Recording" ADD CONSTRAINT "device_m" FOREIGN KEY ("device_id") REFERENCES "Device" ("device_id") ON DELETE SET NULL;
ALTER TABLE "Meter_Recording" ADD CONSTRAINT "meter_staff_m" FOREIGN KEY ("staff_id") REFERENCES "Meter_Staff" ("staff_id") ON DELETE SET NULL;
ALTER TABLE "Meter_Recording" ADD CONSTRAINT "user_m" FOREIGN KEY ("user_id") REFERENCES "User" ("user_id") ON DELETE SET NULL;
ALTER TABLE "Payment_record" ADD CONSTRAINT "user_payment_record" FOREIGN KEY ("user_id") REFERENCES "User" ("user_id") ON DELETE SET NULL;

