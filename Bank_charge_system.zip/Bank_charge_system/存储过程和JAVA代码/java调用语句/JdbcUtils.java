package com.jdbc.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Types;
import java.util.Scanner;

public class JdbcUtils {
	public static void main(String[] args) {
		//��������
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e2)
		{
			e2.printStackTrace();
		} 
		
		//������ݿ�����
		String url = "jdbc:oracle:thin:@localhost:1521:orcl";
		String username = "scott";
		String password = "123";
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, username, password);
			
			//����Statement
			//Statement stat = conn.createStatement();
			
			//�������
			@SuppressWarnings("resource")
			Scanner scanner = new Scanner(System.in);
			int choice;
			CallableStatement cs;
			String bankCode=null;
			int user_id;
			String out_username=null;
			String out_error = null;
			String out_result;
			while(true)
			{
				System.out.println("---------------------------------------");
				System.out.println("     ��ӭ�������д��շ�ϵͳ");
				System.out.println("��ǰ���ӵ����ݿ��û���Ϊ:"+ username+"  ����״̬: ������");
				System.out.println();
				System.out.println();
				System.out.println("     ��ѡ�����Ĳ�����");
				System.out.println("         1.��ѯ");
				System.out.println("         2.�ɷ�");
				System.out.println("         3.����");
				System.out.println("         4.������");
				System.out.println("         5.����ϸ");
				System.out.println("         0.�˳�");				
				System.out.println("---------------------------------------");
				choice = scanner.nextInt();
				switch(choice)
				{
				case 1:
					System.out.print("������ͻ�id: ");
					user_id = scanner.nextInt();
					cs = conn.prepareCall("call SEARCH(?,?,?,?,?,?)");
					cs.setInt(1, user_id);
					cs.registerOutParameter(2, Types.VARCHAR);
					cs.registerOutParameter(3, Types.VARCHAR);
					cs.registerOutParameter(4, Types.VARCHAR);
					cs.registerOutParameter(5, Types.NUMERIC);
					cs.registerOutParameter(6, Types.NUMERIC);
					
					cs.execute();
					out_error = cs.getString(2);
					out_username = cs.getString(3);
					String address = cs.getString(4);
					double needpay = cs.getDouble(5);
					double balance = cs.getDouble(6);
					System.out.println("error:"+out_error);
					System.out.println("username:"+out_username);
					System.out.println("address:"+address);
					System.out.println("needpay:"+needpay);
					System.out.println("balance:"+balance);
					System.out.println();
					System.out.println();
					System.out.println();
					break;
					
				case 2:
					System.out.print("������ͻ�id: ");
					user_id = scanner.nextInt();
					System.out.print("������ɷѽ��: ");
					double need_pay = scanner.nextDouble();
					cs = conn.prepareCall("call PAYMENT(?,?,?,?,?)");
					cs.setInt(1, user_id);
					cs.setDouble(2, need_pay);
					cs.registerOutParameter(3, Types.VARCHAR);
					cs.registerOutParameter(4, Types.VARCHAR);
					cs.registerOutParameter(5, Types.VARCHAR);
					cs.execute();
					out_username = cs.getString(3);
					out_error = cs.getString(4);
					out_result = cs.getString(5);
					System.out.println("username:"+out_username);
					System.out.println("error:"+out_error);
					System.out.println("result:"+out_result);
					System.out.println();
					System.out.println();
					System.out.println();
					break;
				
				case 3:
					System.out.print("�������û�id: ");
					user_id = scanner.nextInt();
					System.out.print("������������: ");
					double correct_fee = scanner.nextDouble();
					System.out.print("������������ˮ��: ");
					int flow_num = scanner.nextInt();
					cs = conn.prepareCall("call \"correct\"(?,?,?,?)");
					cs.setInt(1, user_id);
					cs.setDouble(2,correct_fee);
					cs.setInt(3,flow_num);
					cs.registerOutParameter(4, Types.VARCHAR);
					cs.execute();
					out_result = cs.getString(4);
					System.out.println("result:"+out_result);
					break;
					
				case 4:
					System.out.print("���������д���: ");
					bankCode = scanner.next();
					cs = conn.prepareCall("call \"checktotal\"(?,?)");
					cs.setString(1, bankCode);
					cs.registerOutParameter(2,Types.VARCHAR);
					cs.execute();
					out_result=cs.getString(2);
					System.out.println("result:"+out_result);
					break;
				case 5:
					System.out.print("���������д���: ");
					bankCode = scanner.next();
					cs = conn.prepareCall("call \"checkdetail\"(?,?)");
					cs.setString(1,bankCode);
					cs.registerOutParameter(2,Types.VARCHAR);
					cs.execute();
					out_result=cs.getString(2);
					System.out.println("result:"+out_result);
					
				case 0:
					System.exit(0);
				}
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
		/*	//дsql
			String sql = "select * from SCOTT.\"User\"";
			//ִ�����
			ResultSet rs = stat.executeQuery(sql);
			//��ȡ����
			while(rs.next())
			{
				String str = "";
				str+= "ID:"+rs.getString("user_id")+";";
				str+="Name:"+rs.getString("user_name")+";";
				System.out.println(str);
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
			try {
				conn.rollback();
			}catch(SQLException e1) {}
		}
		finally {
			try {
				conn.close();
			}catch(SQLException e)
			{
				e.printStackTrace();
				}
		}*/
		
	

